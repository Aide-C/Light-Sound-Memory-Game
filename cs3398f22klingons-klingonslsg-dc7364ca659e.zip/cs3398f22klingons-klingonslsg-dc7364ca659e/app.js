/*****************************************************************
app.js

purpose: serves as the connect between local host and index html
         files

methods: n/a

global variables: const - express, bodyParser, router, app,
                  cookieParser, bcrypt, saltRounds, mysql, res,
                  con
*****************************************************************/
//constant variables
const express = require("express");
const bodyParser = require("body-parser");
const router = express.Router();
const app = express();
const cookieParser = require("cookie-parser");
app.use(cookieParser());
const bcrypt = require("bcrypt");
const saltRounds = 5;

const mysql = require("mysql");
const res = require("express/lib/response");
const con = mysql.createConnection({
    user: "sql5528913",
    password: "phqLX4JYQI",
    host: "sql5.freesqldatabase.com",
    database: "sql5528913",
    port: "3306",
});

con.connect(function (err) {
    if (err) throw err;
    console.log("Connected!");
});

app.use(
    bodyParser.urlencoded({
        extended: true,
    })
);
app.use(bodyParser.json());

app.use("/staticDir", express.static(__dirname + "/staticDir"));

app.use("/", router);
app.use("/game", router);
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.get("/", (req, res) => {
    res.sendFile(__dirname + "/login.html");
});

app.get("/game", (req, res) => {
    res.sendFile(__dirname + "/index.html");
});

app.post("/", (req, res) => {
    console.log("checking user in database");

    let username = req.body.username;
    let password = req.body.password;



    var sql = "SELECT * FROM Users WHERE username = '" + username + "';";

    con.query(sql, function (err, result) {
        if (err) throw err;

        if (result.length > 0) {
            sql = "SELECT password FROM Users WHERE username = '" + username + "';";

            con.query(sql, function (err, result) {
                if (err) throw err;

                let pass = result[0].password;
                bcrypt.compare(password, pass, function(err, result) {
                    if (result) {
                        console.log("Password is correct");
                        res.redirect("/game");
                    }
                    else {
                        console.log("Password is incorrect");
                        res.redirect("/")
                    }
                });
            });
        } else {
            console.log("User not found, creating new profile");

            bcrypt.hash(password, saltRounds, function(err, hash) {
                sql = "INSERT INTO Users (Username, Password) VALUES ('" + username + "', '" + hash + "');";

                con.query(sql, function (err, result) {
                    console.log("New user added");
                });

                sql = "INSERT INTO Scores (Username, Score) VALUES ('" + username + "', '" + 0 + "');";
                con.query(sql, function (err, result) {
                    console.log("New score added");
                });
            });

            res.redirect("/game");
        }
    });
});

app.post("/logout", (req, res) => {
    let currentUser = req.cookies.username; // Retrieves username stored as cookie
    let newScore = req.cookies.highscore;

    var sql = "SELECT score FROM Scores WHERE username = '" + currentUser + "';";

    con.query(sql, function (err, result, fields) {
        if (err) throw err;
        var currentScore = result[0].score;

        if (newScore > currentScore) {
            var sql =
                "UPDATE Scores SET score = '" +
                newScore +
                "' WHERE username = '" +
                currentUser +
                "';";

            con.query(sql, function (err, result) {
                if (err) throw err;
                console.log("Score updated");
            });
        }
    });


    console.log("User logged out");
    res.redirect("/");
});

app.listen(3000, () => {
    console.log("Application started and Listening on port 3000");
});
