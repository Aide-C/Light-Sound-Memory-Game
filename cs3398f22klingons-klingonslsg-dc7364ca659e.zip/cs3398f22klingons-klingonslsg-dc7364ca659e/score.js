/*****************************************************************
score.js

purpose: houses methods used in grabbing high scores for a
         specified user and setting them locally for display.

methods: function - HighScores

global variables: n/a
*****************************************************************/

/*
 HighScores

 purpose: grabs specified users high score from the database and
          sets it locally so it can be displayed

 returns: n/a
 */
function HighScores() {
    if(typeof(Storage)!=="undefined"){
        var scores = false;
        if(localStorage["high-scores"]) {
            high_scores.style.display = "block";
            high_scores.innerHTML = '';
            scores = JSON.parse(localStorage["high-scores"]);
            scores = scores.sort(function(a,b){return parseInt(b)-parseInt(a)});

            for(var i = 0; i < 10; i++){
                var s = scores[i];
                var fragment = document.createElement('li');
                fragment.innerHTML = (typeof(s) != "undefined" ? s : "" );
                high_scores.appendChild(fragment);
            }
        }
    } else {
        high_scores.style.display = "none";
    }
}