# Light Sound Game (LSG)

> our group the Klingons consists of Aide Cuevas, Tanner Phillips, Karla Gonzalez and Kolby Morris. We are a group
of determined college kids who have the goal of creating a light and sound based web game. So that we can help
increase our users short term memory as well as foster a friendly competitive enviorment.


> Live demo [_here_](https://lsg-demo.glitch.me).

## Table of Contents
* [General Info](#general-information)
* [Technologies Used](#technologies-used)
* [Features](#features)
* [Screenshots](#screenshots)
* [Setup](#setup)
* [Usage](#usage)
* [Project Status](#project-status)
* [Room for Improvement](#room-for-improvement)
* [Acknowledgements](#acknowledgements)
* [Contact](#contact)
<!-- * [License](#license) -->


## General Information

![Team Icon](./Image/image.jpg)

## Technologies Used
- Tech 1 - [Javascript](https://www.javascript.com/)
- Tech 2 - [Jira](https://www.atlassian.com/software/jira)
- Tech 3 - [BitBucket](https://bitbucket.org/product)
- Tech 4 - [gitKraken](https://www.gitkraken.com/)
- Tech 5 - [Glitch](https://glitch.com)
- Tech 6 - [mySQL + phpMyAdmin](https://www.phpmyadmin.net)


## Features
* Login and sign up page
  * Allow users to login or sign up to our website so that we can keep their high scores
  * User Stories Kolby - GUI for login and sign up page, Karla Backend for login and signup page
* User settings page
  * Allow users to alternate settings so that they can tailor the game experience to them
  * USER STORIES: Tanner building preference page, Aide allowing changes to colors and speed of music

## Screenshots

## Setup
- Accessing the database
    - Follow this [link to phpMyAdmin](https://www.phpmyadmin.co) and enter the information in the appropriate boxes:
        - username: sql5528913
        - password: phqLX4JYQI
        - host/server: sql5.freesqldatabase.com
## Usage

## Sprint 1
![Team Icon](./Image/LoginSprint1.jpg)
![Team Icon](./Image/SignupSprint1.jpg)

## Contributions
- **Kolby**: "Added in sign in and login in forms to begin process for keeping track of users"
    - Jira Task: [Create Layout for sign up page](https://cs3398f22klingon.atlassian.net/jira/software/projects/KLIN/boards/2?selectedIssue=KLIN-10)
        - reference: https://bitbucket.org/cs3398f22klingons/klingonslsg/commits/e67882242199f4ee7dd93bd125ce52425413cf7e
    - Jira Task: [Create layout for login page](https://cs3398f22klingon.atlassian.net/jira/software/projects/KLIN/boards/2?selectedIssue=KLIN-2)
        - reference: https://bitbucket.org/cs3398f22klingons/klingonslsg/commits/e67882242199f4ee7dd93bd125ce52425413cf7e
    - Jira Task: [Display signup/login page before LSG game](https://cs3398f22klingon.atlassian.net/jira/software/projects/KLIN/boards/2?selectedIssue=KLIN-11)
        - reference: https://bitbucket.org/cs3398f22klingons/klingonslsg/commits/17c787bc3dcf8308dd77ee16073dcd8385e04dca
    - Jira Task: [Ensure interactions between the backend and frontend signup/login process](https://cs3398f22klingon.atlassian.net/jira/software/projects/KLIN/boards/2?selectedIssue=KLIN-12)
        - reference: https://bitbucket.org/cs3398f22klingons/klingonslsg/commits/17c787bc3dcf8308dd77ee16073dcd8385e04dca
    <br />
- **Karla**: "Added script to check for validity of user passwords and to store user information"
    - Jira Task 21: [Ensure there are no duplicate usernames or email addresses](https://cs3398f22klingon.atlassian.net/browse/KLIN-21?atlOrigin=eyJpIjoiMzQ4NjA2NDU3NjhhNDg0NGJhYzNlNWExNTkxNzg0YjEiLCJwIjoiaiJ9)
        - reference: https://bitbucket.org/cs3398f22klingons/klingonslsg/commits/00c3ad41489fb6b0f865c6c66fe35fdb493211e0
    - Jira Task 22: [Create database to store all username and passwords](https://cs3398f22klingon.atlassian.net/browse/KLIN-22?atlOrigin=eyJpIjoiMDAwM2ViNjk4ZmU2NDg2YzgwMjIxM2I5ZTdmNjNjZDAiLCJwIjoiaiJ9)
        - reference: https://bitbucket.org/cs3398f22klingons/klingonslsg/commits/2338afc6c4263df22b5af61e4a52326f0f600a8f
    - Jira Task 23: [Ensure new passwords follow security guidelines](https://cs3398f22klingon.atlassian.net/browse/KLIN-23?atlOrigin=eyJpIjoiNWJjN2I4MzFjZjRiNDYyMTkxM2Q0MTk0MjNmZWY3MTIiLCJwIjoiaiJ9)
        - reference: https://bitbucket.org/cs3398f22klingons/klingonslsg/commits/5ab595a07eaf0f86f281b217050d8ba4c9ea1439
    - Jira Task 25: [Learn JavaScript](https://cs3398f22klingon.atlassian.net/browse/KLIN-25?atlOrigin=eyJpIjoiNDJlNzVmNjc1NGM1NDNjMzk4NGY3NzljNWQzMzVlMTUiLCJwIjoiaiJ9)
    <br />
- **Aide**: "Added code to randomize the frequencys of the buttons, pattern which the buttons play, background song, and difficulty increase/decrease"
    - Jira Task: [Randomize the pattern] (https://cs3398f22klingon.atlassian.net/browse/KLIN-17?atlOrigin=eyJpIjoiYTZiNzZmOWNiMTI4NDFjMGEyNDllMWY3NDIyNjg0YzMiLCJwIjoiaiJ9)
       - reference: https://bitbucket.org/cs3398f22klingons/klingonslsg/commits/71db2421d14c3b7b7e8b9162a791ac09a3de39e8 
    - Jira Task: [Randomize sound frequencies] (https://cs3398f22klingon.atlassian.net/browse/KLIN-19?atlOrigin=eyJpIjoiNzVmNTFlMzdhNmZlNDM3Yjg0YjI1Y2U5NDM0YjFjYTMiLCJwIjoiaiJ9)
       - reference: https://bitbucket.org/cs3398f22klingons/klingonslsg/commits/0660c690c423603e58ce7801c16722f80e7501ef
    - Jira Task: [Add background song] (https://cs3398f22klingon.atlassian.net/browse/KLIN-20?atlOrigin=eyJpIjoiMDNjMTdlYTVhMDJhNDA4NWFlYzI3ODJhNDAzYjg3NTIiLCJwIjoiaiJ9)
       - reference: https://bitbucket.org/cs3398f22klingons/klingonslsg/commits/e8699bd2d754cc9570be8581baf990eef0d4805e
    - Jira Task: [Code to increase/decrease difficulty] (https://cs3398f22klingon.atlassian.net/browse/KLIN-18?atlOrigin=eyJpIjoiYWExODdhYWI3Y2FiNGE1YjliYzZiMTkyZjQzNDhiYjAiLCJwIjoiaiJ9)
       - reference: https://bitbucket.org/cs3398f22klingons/klingonslsg/commits/063a100f7782062bf9ea90005b94f148eead299c
    <br />
- **Tanner**: "Added UI elements for the settings page, making sure layout was correct, and 
ensured the functionality of the page itself rather than its contents."
    - Jira Task: [Learn HTML and subsequent tools](https://cs3398f22klingon.atlassian.net/browse/KLIN-15?atlOrigin=eyJpIjoiZTQxMjhjYmU3NTc4NGYyNGFiYjQ4YzNhMGNhZGE3ZjQiLCJwIjoiaiJ9)    
    - Jira Task: [create settings page](https://cs3398f22klingon.atlassian.net/browse/KLIN-14?atlOrigin=eyJpIjoiODFiNjAwZTJkNmU0NDI4Zjg3NGM5MWUzNzc2MWQzOTkiLCJwIjoiaiJ9)
        - reference:https://bitbucket.org/cs3398f22klingons/klingonslsg/commits/10eb0b1c3697488d3db78661a1fa4e02a7abce82  
    - Jira Task: [add buttons for difficulty settings and color blind mode](https://cs3398f22klingon.atlassian.net/browse/KLIN-13?atlOrigin=eyJpIjoiOTdmOGUzNjJiYTY0NDMyZThiMDhhZjAyNmE2MWU3ODYiLCJwIjoiaiJ9) 
        - reference: https://bitbucket.org/cs3398f22klingons/klingonslsg/commits/0ae68c88aee9b33279d6730cdbc38ee5105aee04
    - Jira Task: [Be able to select difficulty in settings](https://cs3398f22klingon.atlassian.net/browse/KLIN-16?atlOrigin=eyJpIjoiOTcyOWI3ZmU2OWFhNGViZmE2YzJhYmNjNDZhZDdmNTYiLCJwIjoiaiJ9)
        - reference: https://bitbucket.org/cs3398f22klingons/klingonslsg/commits/ed3638153ce1b95088d782ae27cf46e2ed3f4ef8
## Next Steps
- Kolby
    - center login and sign up forms and create high score page
- Karla
    - Improve current code and add function to calculate and score high scores

- Aide
    - Fix the bugs in my code and start code for leader/score board
- Tanner
    - Improve aesthetic for the settings page, as well as adding in full functionality

## Room for Improvement
- Aide 
    - Improve time management 
    - Pratice more with GitKraken
- Tanner
    - Further my understanding of the languages used
    - Improve with time management
- Karla
    - Better my time management
    - Improve my knowledge of JavaScript and the other languages used

___
## Sprint 2
![Team Icon](./Image/gameScreen.jpg)
![Team Icon](./Image/GameOver.jpg)

## Contributions
- **Kolby**: "Created score page along with adding in a cleaner design to the UI"
    - Jira Task: [Create high score page](https://cs3398f22klingon.atlassian.net/jira/software/projects/KLIN/boards/2?selectedIssue=KLIN-30)
        - reference: [View on Bitbucket](https://bitbucket.org/cs3398f22klingons/%7Bffe6305e-65ba-460d-9ea3-88e4be28dfef%7D/commits/98993a5d0fc2f13e93d9646732fd93d721ebde83)
    - Jira Task: [Finish styling signup/login forms](https://cs3398f22klingon.atlassian.net/jira/software/projects/KLIN/boards/2?selectedIssue=KLIN-31)
        - reference: [View on Bitbucket](https://bitbucket.org/cs3398f22klingons/%7Bffe6305e-65ba-460d-9ea3-88e4be28dfef%7D/commits/a0788367108abf65380a78135c89dd4dd714081a)
    - Jira Task: [Style and format score display](https://cs3398f22klingon.atlassian.net/jira/software/projects/KLIN/boards/2?selectedIssue=KLIN-32)
        - reference: [View on Bitbucket](https://bitbucket.org/cs3398f22klingons/%7Bffe6305e-65ba-460d-9ea3-88e4be28dfef%7D/commits/ae46cc9e96dcb05cf3259f5c2764794e743c40ed)
    - Jira Task: [Research frontend component library](https://cs3398f22klingon.atlassian.net/jira/software/projects/KLIN/boards/2?selectedIssue=KLIN-33)
        - reference: [View on Bitbucket](https://bitbucket.org/cs3398f22klingons/%7Bffe6305e-65ba-460d-9ea3-88e4be28dfef%7D/commits/8f53d9f749c0fe41af489738033b002dc303feb5)
          <br />
- **Karla**: "Created backend functions that implemented the project’s database"

    - Jira Task 24: [Create a compare passwords function that interacts with DB](https://cs3398f22klingon.atlassian.net/browse/KLIN-24?atlOrigin=eyJpIjoiZDMyMjc2Mjg3YWVkNGZjZDhiMjdjZDQ3YzQ2ZTMyZjEiLCJwIjoiaiJ9)
        - reference: [View on Bitbucket](https://bitbucket.org/cs3398f22klingons/klingonslsg/commits/d7b64a64eb56cb0aebf8365d2481faf701fb25bb)
    - Jira Task 34: [Ensure program is writing and reading from the database correctly](https://cs3398f22klingon.atlassian.net/browse/KLIN-34?atlOrigin=eyJpIjoiOGIzNmQwZGE4NzRjNDY1MWJhN2JjNWQ3NzE1MmE2YTAiLCJwIjoiaiJ9)
        - reference: [View on Bitbucket](https://bitbucket.org/cs3398f22klingons/klingonslsg/commits/e937323987e23faf23dfb172c2ce73dee13abeb2)
    - Jira Task 36: [Create a database that will store a users high score](https://cs3398f22klingon.atlassian.net/browse/KLIN-36?atlOrigin=eyJpIjoiNmFhNTczNDRiMTNlNDk5MDgyOGMwNDIyYzY3ODM3NzgiLCJwIjoiaiJ9)
        - reference: [View on Bitbucket](https://bitbucket.org/cs3398f22klingons/klingonslsg/commits/294cb6e0efc11bad0e8984ec1ee8a8e9859be0c5)
    - Jira Task 37: [create a function that stores users high scores in the database](https://cs3398f22klingon.atlassian.net/browse/KLIN-37?atlOrigin=eyJpIjoiOWVhOWZhNjk5NzI4NGJiNTg1OGFlOWVmODBlYWRjYzgiLCJwIjoiaiJ9)
        - reference: [View on Bitbucket](https://bitbucket.org/cs3398f22klingons/klingonslsg/commits/3c75f111b11931f4ec09942befcd238cf7ff564d)
            <br />
- **Aide**: "Created new setting features add/subtract buttons and colorblind, fix difficulty levels, and logic for scoreboard"
    - Jira Task: [Fix difficulty levels glitch](https://cs3398f22klingon.atlassian.net/browse/KLIN-39?atlOrigin=eyJpIjoiM2E4MTU5OTRkMjgzNDJkNzk2NDQxMzYwM2U2YWZkOTkiLCJwIjoiaiJ9)
        - reference: [View on Bitbucket](https://bitbucket.org/cs3398f22klingons/klingonslsg/commits/cb70d0dcc7de3d6059470c771115ca75a950832c)
    - Jira Task: [Create backend logic for scoreboard display](https://cs3398f22klingon.atlassian.net/browse/KLIN-40?atlOrigin=eyJpIjoiZjA1NzRhNWY3OGU5NDhmMWIxOGU3OGFkZTA4OTlmZjIiLCJwIjoiaiJ9)
        - reference: [View on Bitbucket](https://bitbucket.org/cs3398f22klingons/klingonslsg/commits/58c18df1e9891a618f70d0d3c3b75bea319ed988) 
    - Jira Task: [Create add/subtract buttons feature](https://cs3398f22klingon.atlassian.net/browse/KLIN-38?atlOrigin=eyJpIjoiZTU4OWVhOGQyNDFiNGExMTkwOGVjMDdhMzQyN2UzZDYiLCJwIjoiaiJ9)
        - reference:[View on Bitbucket](https://bitbucket.org/cs3398f22klingons/klingonslsg/commits/fd528e025de2788ed0f01597c7bb42525e5e7f00)
    - Jira Task: [Create logic for colorblind option](https://cs3398f22klingon.atlassian.net/browse/KLIN-41?atlOrigin=eyJpIjoiZjY5MTljNmNhY2M0NDk5MThlMWE0YTk5MmRmM2Y2NWEiLCJwIjoiaiJ9)
        - reference: [View on Bitbucket](https://bitbucket.org/cs3398f22klingons/klingonslsg/commits/859372d8c4328e236ab446e6111c178922872bcc)

- **Tanner**: ""
    - Jira Task: [continue styling Settings page](https://cs3398f22klingon.atlassian.net/browse/KLIN-42?atlOrigin=eyJpIjoiNzhlYjYwMmJhMzc1NGI2YmE3NTg5NjQ2NGM4MGE0NjgiLCJwIjoiaiJ9)
        - reference: [View on Bitbucket](https://bitbucket.org/cs3398f22klingons/klingonslsg/commits/ade53450a604941844142141053d609f55127b6f)
    - Jira Task: [rework game button display logic](https://cs3398f22klingon.atlassian.net/browse/KLIN-43?atlOrigin=eyJpIjoiZTMyNTkxOGVhMTY1NDU5YThlYjViMDA1NmE5ODgyOGQiLCJwIjoiaiJ9)
        - reference: [View on Bitbucket](https://bitbucket.org/cs3398f22klingons/klingonslsg/commits/8b669ede7426f7cc720e624842d0559e317d1975)
    - Jira Task: [create custom game over popup](https://cs3398f22klingon.atlassian.net/browse/KLIN-44?atlOrigin=eyJpIjoiMGZiNmVlNTI3MTM2NGJiMTg5ODU1NjY5NTg4NTc5ZmUiLCJwIjoiaiJ9)
        - reference:[View on Bitbucket](https://bitbucket.org/cs3398f22klingons/klingonslsg/commits/2444656fdf9d2c438f1d9069142c3a077092b7d6)
    - Jira Task: [Refactor game page UI](https://cs3398f22klingon.atlassian.net/browse/KLIN-45?atlOrigin=eyJpIjoiM2M1MjY4MDMzMTg5NGNiMzgzMGIxNDNmNDMzZjc4MTAiLCJwIjoiaiJ9)
        - reference: [View on Bitbucket](https://bitbucket.org/cs3398f22klingons/klingonslsg/commits/d0cefc85f75d705f7aeb8577c32b78c01f5bc2fe)
## Next Steps
- Kolby
    - Work with Karla to connect our login/signup features on the website to the database
- Karla
    - Work with Kolby to connect the frontend and backend of the login/signup features
- Aide
    - Work with Tanner and Karla on the backend of the scoreboard, scores, and add/subtract buttons feature
- Tanner
    - Continue developing UI and add other features 
## Room for Improvement
- Kolby
    - Quicker debugging strategies
    - Communicate final vision with team sooner on tasks
- Karla
    - Keep improving my knowledge of the languages being used
    - Communicate with the team better when I encounter a problem
- Aide
    - Better time management of my tasks
    - Ask for help when my code conflicted with the main branch
- Tanner
    - Better time management is a must, too many things went in too late.
    - Learn to structure UI better as to not cause problems with positioning later on
## Sprint 3

## Contributions
- **kolby**: "Cleaned up bugs while finishing configuration of signup and login pages"

    - Jira Task 47: [Isolate and fix bugs in website](https://cs3398f22klingon.atlassian.net/browse/KLIN-47)
        - reference: [View on Bitbucket](https://bitbucket.org/cs3398f22klingons/klingonslsg/commits/20e1adb780e017b81998f62e1286d97759fbfe09)
    - Jira Task 48: [Finish login page functionality](https://cs3398f22klingon.atlassian.net/browse/KLIN-48)
        - reference: [View on Bitbucket](https://bitbucket.org/cs3398f22klingons/%7Bffe6305e-65ba-460d-9ea3-88e4be28dfef%7D/commits/e73957d620c9d6cffc3e9a7cfc588a9fa3fb7c85)
    - Jira Task 49: [Create personal score page](https://cs3398f22klingon.atlassian.net/browse/KLIN-49)
        - reference: [View on Bitbucket](https://bitbucket.org/cs3398f22klingons/%7Bffe6305e-65ba-460d-9ea3-88e4be28dfef%7D/commits/98263c446b61ddd42bffd12ab8037e1a443a99ac)
    - Jira Task 50: [Create backend functionality with score page](https://cs3398f22klingon.atlassian.net/browse/KLIN-50)
        - reference: [View on Bitbucket](https://bitbucket.org/cs3398f22klingons/%7Bffe6305e-65ba-460d-9ea3-88e4be28dfef%7D/commits/259a313c4176e2a4ef761c9eb15a834f3850f57e)
          <br />
      
- **Karla**: "Added function to further improve password security and implemented functions that connect to a database"

    - Jira Task 51: [ensure backend functionality for login is working](https://cs3398f22klingon.atlassian.net/browse/KLIN-51?atlOrigin=eyJpIjoiYjZiMDNlNTU3NTg4NGM2MWFhM2RiOGY3YTY3OTZjNzQiLCJwIjoiaiJ9)
        - reference: [View on Bitbucket](https://bitbucket.org/cs3398f22klingons/%7Bffe6305e-65ba-460d-9ea3-88e4be28dfef%7D/commits/d53e2f4fc2c073ea01f2fab70aeae039c4576024)
    - Jira Task 52: [ensure backend functionality for signup is working](https://cs3398f22klingon.atlassian.net/browse/KLIN-52?atlOrigin=eyJpIjoiZTE5ZWU0ZDVjMTE2NGQ1ZmI5YmY5MTY1MjJhYjdlZGUiLCJwIjoiaiJ9)
        - reference: [View on Bitbucket](https://bitbucket.org/cs3398f22klingons/%7Bffe6305e-65ba-460d-9ea3-88e4be28dfef%7D/commits/1631db42943b113630a69a5286172dd9b5f37c21)
    - Jira Task 53: [ensure correct configuration of high score functions](https://cs3398f22klingon.atlassian.net/browse/KLIN-53?atlOrigin=eyJpIjoiMzUxNjY0MWU0NzlmNGJmZTllOTdlYzZjNDk4MTEwYzYiLCJwIjoiaiJ9)
        - reference: [View on Bitbucket](https://bitbucket.org/cs3398f22klingons/%7Bffe6305e-65ba-460d-9ea3-88e4be28dfef%7D/commits/ad2fdf770b3c8eb75fe6c69863a72d4cd30c3fc4)
    - Jira Task 54: [ensure password management features are properly set up](https://cs3398f22klingon.atlassian.net/browse/KLIN-54?atlOrigin=eyJpIjoiNjVhZGM4ZWQwMDE0NDNkMGFlOGIyNGJiNzZkNDk1N2YiLCJwIjoiaiJ9)
        - reference: [View on Bitbucket](https://bitbucket.org/cs3398f22klingons/%7Bffe6305e-65ba-460d-9ea3-88e4be28dfef%7D/commits/6e18649c572ab84c00e2a0a8d6d8da4e17f8efff)
    <br />

- **Tanner**: "Completed UI updates with multiple elements, refactored the library and code within, and added leaderboard UI"

    - Jira Task 59: [Refactor file systems](https://cs3398f22klingon.atlassian.net/browse/KLIN-59?atlOrigin=eyJpIjoiNzM1ZjdlMTVhMGQ0NGRjMmI2N2ZhN2NjODEyYzQwZmEiLCJwIjoiaiJ9)
        - reference: [View on Bitbucket](https://bitbucket.org/cs3398f22klingons/klingonslsg/commits/f2383561d24ecfc87a336c69572e08feac9f0305)
    - Jira Task 60: [Housecleaning of all existing code](https://cs3398f22klingon.atlassian.net/browse/KLIN-60?atlOrigin=eyJpIjoiOWE2YjcwZTJlOWFkNDFiNWE1MjVlNzFjYmNhMGMxMTEiLCJwIjoiaiJ9)
        - reference: [View on Bitbucket](https://bitbucket.org/cs3398f22klingons/klingonslsg/commits/dd750095844f8085c3f664f9a41928bcbf9bb2f7)
    - Jira Task 61: [Making UI borders responsive](https://cs3398f22klingon.atlassian.net/browse/KLIN-61?atlOrigin=eyJpIjoiYjEyMWE3YWEwNDQyNDc3ZmEwM2IwNDNlNTVhMTUxMzUiLCJwIjoiaiJ9)
        - reference: [View on Bitbucket](https://bitbucket.org/cs3398f22klingons/klingonslsg/commits/a2bcd691880e1950e6ea2dce23c5bb8730bf97a9)
    - Jira Task 62: [Create leaderboard UI (subject to change)](https://cs3398f22klingon.atlassian.net/browse/KLIN-62?atlOrigin=eyJpIjoiMWYzNTc0ZWJjNzBhNDcwOGJhODQ2NjRjZjQxZDk2YmYiLCJwIjoiaiJ9)
        - reference: [View on Bitbucket](https://bitbucket.org/cs3398f22klingons/klingonslsg/commits/0e31c6a6d5de66fd81302de6779d452b07b100c5)
          <br />

- **Aide**: "Added levels to the game, 3 tries limit, fix bugs from my code in the last sprint, and connect database to the leaderboard"

    - Jira Task 57:[3 Tries Limit](https://cs3398f22klingon.atlassian.net/browse/KLIN-57?atlOrigin=eyJpIjoiZDk0OGM0NmNlMzEyNDAwMGI0NDc4NDk2MjAxNzQxYjUiLCJwIjoiaiJ9)
        - reference:[View on Bitbucket](https://bitbucket.org/cs3398f22klingons/klingonslsg/commits/f9c1924979ccdae9c656fa63f9db46a123cbab60)
    - Jira Task 55:[Fix Bugs From Last Sprint](https://cs3398f22klingon.atlassian.net/browse/KLIN-55?atlOrigin=eyJpIjoiODI2YWE1NDkzMzQwNGFkMzk1YmQ0NDNjMjJmYWZiMTciLCJwIjoiaiJ9)
        - reference:[View on Bitbucket](https://bitbucket.org/cs3398f22klingons/klingonslsg/commits/844478135e55da54a831c80f530f9bc2cc008961)
    - Jira Task 58:[Create the 6 Levels with Buttons](https://cs3398f22klingon.atlassian.net/browse/KLIN-58?atlOrigin=eyJpIjoiMGQ0OWFjZjRkMzliNDRmYTgwZmI4YTMxYmQ4ZGU2ZTAiLCJwIjoiaiJ9)
        - reference:[View on Bitbucket](https://bitbucket.org/cs3398f22klingons/klingonslsg/commits/a10fe283729e96a9fa700c19ef00e05d0547aa97)
    - Jira Task 56:[Create Scoreboard Functionality](https://cs3398f22klingon.atlassian.net/browse/KLIN-56?atlOrigin=eyJpIjoiOTI0MWQyNThhMDUwNGRkYmIwZDYyZjQ3NzBhODk3NzciLCJwIjoiaiJ9)
        - reference:[View on Bitbucket](https://bitbucket.org/cs3398f22klingons/klingonslsg/commits/0cb3d9a0c9833970f40506b568dce812b4a8ec52)
    <br />
## Next Steps
- Karla
    - Add a way to update a user's highscore in the database when the window/webpage is closed without loging out

- Tanner
    - Help with the link between database and leaderboard UI, and make colorblind mode functional

- Aide 
    - Fix any bugs in the code, randomize the sound frequencies better, and speed-up pattern when leveling up

- Kolby
    - Create a system that changes the colors and sounds between each game for the user
## Room for Improvement
- Karla 
    - Ask for help sooner rather than later
    - Continue to improve my knowledge with the languages used

-Tanner
    - Further my knowledge of database linking and web hosting
    - Time management is a big one, started off good but let other things get in the way. Next time!

- Aide 
    - Not procrastinate on my last task
    - Ask for help with sql and php for the leaderboard and database connection

- Kolby
    - increase communication with team especially over weekends
    - finish more tasks in the first half of the sprint
  
## Acknowledgements

## Contact
