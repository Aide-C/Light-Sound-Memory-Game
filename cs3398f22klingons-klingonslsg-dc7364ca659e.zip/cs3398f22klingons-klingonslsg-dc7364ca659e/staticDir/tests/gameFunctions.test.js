const {stopGame, startGame} = "./gameFunctions.js";

test('stopGame did not execute', () => {

    const stopGame = jest.fn(() => true);

    stopGame();

    expect(stopGame).toHaveReturned();
})

test('startGame did not execute', () => {
    const startGame = jest.fn(() => true);

    startGame();

    expect(startGame).toHaveReturned();
})