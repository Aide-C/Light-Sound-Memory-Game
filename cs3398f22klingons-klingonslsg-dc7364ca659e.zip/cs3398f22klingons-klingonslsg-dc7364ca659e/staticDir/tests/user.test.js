const {findUser, checkPassword} = "./user.js";

test('findUser returns', () => {
    const userFound = jest.fn(() => true);

    userFound();

    expect(userFound).toHaveReturned();
});

test('checkPassword returns', () => {
    const checkPassword = jest.fn(() => false);

    checkPassword();

    expect(checkPassword).toHaveReturned();
});

