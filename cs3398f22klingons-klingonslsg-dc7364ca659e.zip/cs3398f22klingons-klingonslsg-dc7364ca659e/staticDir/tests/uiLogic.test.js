const {findUser} = "./authFunctions";
const {findHighScore} = "./uiLogic"

describe('do not allow game to not clear values between each unique player', () => {
    test('username is cleared and is not storing anything before assignment', () => {
        expect(findHighScore).toBe(undefined);
    });

    test('username and password are cleared and not storing anything before assignment', () => {
        expect(findUser).toBe(undefined);
    });
});