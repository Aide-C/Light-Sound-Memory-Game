/*****************************************************************
authFunctions.js

purpose: houses methods used in generating error messages for
         authentication of users.

methods: function - setInputError, clearInputError

global variables: n/a
*****************************************************************/

 /*
 setInputError

 purpose: sets errors for invalid input at authentication

 returns: n/a
 */
 function setInputError(inputElement, message) {
    inputElement.classList.add("form__input--error");
    inputElement.parentElement.querySelector(
      ".form__input-error-message"
    ).textContent = message;
  }

   /*
   clearInputError

   purpose: clears text content in .form__input-error-message

   returns: n/a
   */
   function clearInputError(inputElement, message) {
    inputElement.classList.remove("form__input--error");
    inputElement.parentElement.querySelector(
      ".form__input-error-message"
    ).textContent = "";
  }