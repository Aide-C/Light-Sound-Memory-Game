/*****************************************************************
uiLogic.js

purpose: contains all logic used to make ui responsive to user
         input, as well as all backend game functionality

methods: easyLvl, medLvl, hardLvl, startGame, stopGame, playTone,
         startTone, stopTone, lightButton, clearButton,
         playSingleClue, loseGame, winGame, guess, levelUp,
         changeButtons, setCookies

global variables: const - settingsAreaForm, userProfileForm,
                  scoreForm, gameButtonArea,  gameButtonAreaClass,
                  gameOverArea, triesArea
                  let - pattern, progress, gamePlaying, volume,
                  tries, tonePlaying,  guessCounter,  freqMap,
                  score, btns, lvl, clueHoldTime, cluePauseTime,
                  nextClueWaitTime
*****************************************************************/

//constant variables
const settingsAreaForm = document.querySelector("#settingsArea");
const userProfileForm = document.querySelector("#userProfilePage");
const scoreForm = document.querySelector("#score");
const gameButtonArea = document.querySelector("#gameButtonArea");
const gameButtonAreaClass = document.querySelector(".gameButtonArea");
const gameOverArea = document.querySelector("#gameOverArea");
const triesArea = document.querySelector("#triesArea");
// const changeNumButtons = document.querySelector("#changeNumButtons"); commented out because logic was breaking build
//Global Variables
let pattern = [[], [], [], [], [], []]; //keep track of the secret pattern of button presses
let progress = 0; //int represent how far the player is in guessing the pattern
let gamePlaying = false; //boolean to keep track of whether the game is currently active
let volume = 0.5; //keep track whether there is a tone playing, must be between 0.0 and 1.0
let tries = 3;
let reset = false;
let tonePlaying = false; //keep track of where the  user is in the clue sequence
let guessCounter = 0;
let freqMap = {};
let score = 0;
let btns = 3;
let lvl = 0;
//Timing variables - standard
let clueHoldTime = 0; //how long to hold each clue's light/sound
let cluePauseTime = 0; //how long to pause in between clues
let nextClueWaitTime = 0; //how long to wait before playing sequence

//update variable to match that of one in DB
let highscore = 0;
if(highscore === 0){
  document.getElementById("userHighScore").innerHTML = "0" +"\n"+"play a game to earn your first high score";
}

//Game Logic
function easyLvl(){
  let x = document.getElementById("startBtn");
  if (window.getComputedStyle(x).visibility === "hidden"){
    x.style.visibility = "visible";
  }

  clueHoldTime = 1500;
  cluePauseTime = 516;
  nextClueWaitTime = 1500;
  document.getElementById("startBtn").classList.add("remove");
}

function medLvl(){
  let x = document.getElementById("startBtn");
  if (window.getComputedStyle(x).visibility === "hidden"){
    x.style.visibility = "visible";
  }

  clueHoldTime = 1000;
  cluePauseTime = 333; //will stay the same for this  difficulty level
  nextClueWaitTime = 1000;
  document.getElementById("startBtn").classList.add("remove");
}

function hardLvl(){
  var x = document.getElementById("startBtn");
  if (window.getComputedStyle(x).visibility === "hidden"){
    x.style.visibility = "visible";
  }

  clueHoldTime = 500;
  cluePauseTime = 150;
  nextClueWaitTime = 500;
  document.getElementById("startBtn").classList.add("remove");
}

function startGame() {
  //initialize game variables
  gameButtonArea.classList.remove("form--hidden");
  gameOverArea.classList.add("form--hidden");
  scoreForm.classList.add("form--hidden");
  triesArea.classList.remove("form--hidden");
  // changeNumButtons.classList.remove("form--hidden");
  progress = 0;
  gamePlaying = true;

  let numBtns = 3; 
  for (let b = 0; b < 6; ++b){
    for (let i = 0; i < numBtns; ++i){
      pattern[b][i] = Math.floor(Math.random() * numBtns) + 1; //fix pattern[i](level) = buttons # needed
    }
    ++numBtns; //should make go up to 8 butons
  }

  let currFreq = Math.random() * 120 + 120; //makes frequency audible
  for (let i = 0; i < 8; ++i){
    freqMap[i+1] = currFreq + 30 * i; //changes the frequencies after each loop and adds to the freq-map array
  }

  //swap the Start and Stop buttons
  document.getElementById("startBtn").classList.add("hidden");
  document.getElementById("stopBtn").classList.remove("hidden");
  playClueSequence();
}

function stopGame() {
  //ends game variables
  gamePlaying = false;
  if (reset === true){
    tries = 3;
    reset = false;
    document.getElementById("triesCount").innerHTML = tries;
  }

  lvl = 0;
  btns = 3;
  changeButtons();

  //swap the Start and Stop buttons
  document.getElementById("startBtn").classList.remove("hidden");
  document.getElementById("stopBtn").classList.add("hidden");
}

function playTone(btn, len) {
  o.frequency.value = freqMap[btn];
  g.gain.setTargetAtTime(volume, context.currentTime + 0.05, 0.025);
  context.resume()
  tonePlaying = true;
  setTimeout(function () {
    stopTone();
  }, len);
}

function startTone(btn) {
  if (!tonePlaying) {
    context.resume();
    o.frequency.value = freqMap[btn];
    g.gain.setTargetAtTime(volume, context.currentTime + 0.05, 0.025);
    context.resume();
    tonePlaying = true;
  }
}

function stopTone() {
  g.gain.setTargetAtTime(0, context.currentTime + 0.05, 0.025);
  tonePlaying = false;
}

// Page Initialization
// Init Sound Synthesizer
let AudioContext = window.AudioContext || window.webkitAudioContext;
let context = new AudioContext();
let o = context.createOscillator();
let g = context.createGain();
g.connect(context.destination);
g.gain.setValueAtTime(0, context.currentTime);
o.connect(g);
o.start(0);

function lightButton(btn) {
  document.getElementById("button" + btn).classList.add("lit");
}

function clearButton(btn) {
  document.getElementById("button" + btn).classList.remove("lit");
}

function playSingleClue(btn) {
  if (gamePlaying) {
    lightButton(btn);
    playTone(btn, clueHoldTime);
    setTimeout(clearButton, clueHoldTime, btn);
  }
}

function playClueSequence() {
  guessCounter = 0;
  let delay = nextClueWaitTime;
  for (let i = 0; i <= progress; i++) {
    console.log("play single clue: " + pattern[lvl][i] + " in " + delay + "ms");
    setTimeout(playSingleClue, delay, pattern[lvl][i]);
    delay += clueHoldTime;
    delay += cluePauseTime;
  }
}


function loseGame() {
  scoreForm.classList.remove("form--hidden");
  gameButtonArea.classList.add("form--hidden");
  gameOverArea.classList.remove("form--hidden");
  triesArea.classList.add("form--hidden");
  document.getElementById("score-page").innerHTML = score.toString();
  if(highscore < score){
    document.getElementById("userHighScore").innerHTML = score.toString();
    document.cookie = 'highscore=' + score;
  }
  stopGame();
}

function winGame() {
  stopGame();
  scoreForm.classList.remove("form--hidden");
  document.getElementById("score-page").innerHTML += guessCounter;
  if(highscore < score){
    document.getElementById("userHighScore").innerHTML = score.toString();
    document.cookie = 'highscore=' + score;
  }
}

function guess(btn) {
  score++
  if (!gamePlaying) {
    return;
  }

  if (pattern[lvl][guessCounter] == btn){
    if (lvl != 5){
      if (guessCounter == progress){
        if (progress == pattern[lvl].length - 1){ 
          alert("You passed level " + (lvl+1) + "! Click OK to continue!");
          ++lvl;
          levelUp();
          progress = 0; 
          playClueSequence();
        }else{
          ++progress;
          playClueSequence();
        }
      }else{
        ++guessCounter;
      }
    }else{
      if (guessCounter == progress){
        if (progress == 7){
          winGame();
        }else{
          ++progress;
          playClueSequence();
        }
      }else{
        ++guessCounter;
      }
    }
  }else{ //decrement tries when player misses
    if (tries != 0){
      reset = true;
      --tries;
      document.getElementById("triesCount").innerHTML = tries; 
    }else{
      loseGame();
    }
  }
}

function levelUp() {
  // adjusts the number of playing buttons for each level
  if (btns < 8) {
    ++btns;
    console.log("Buttons: " + btns);

    changeButtons();
  }
}

function changeButtons() {
  // hides or shows buttons needed at a level
  for (let i = 1; i <= btns; i++) {
    document.getElementById("button" + i).hidden = false;
  }
  for (let i = btns + 1; i <= 8; i++) {
    document.getElementById("button" + i).hidden = true;
  }
  if(btns <= 3){
    gameButtonArea.style.height = '170px';
    gameOverArea.style.height = '170px';
  }
  else if (btns >= 4 && btns <= 6){
    gameButtonArea.style.height = '330px';
    gameOverArea.style.height = '330px';
  }
  else if (btns > 6){
    gameButtonArea.style.height = '330px';
    gameButtonArea.style.width = '645px';
    gameOverArea.style.height = '330px';
    gameOverArea.style.width = '645px';
  }
}

function setCookies() {
    document.cookie = 'username=' + document.getElementById('username').value;
    document.cookie ='highscore=' + 0;
}

//logic dealing with displaying UI
document.querySelector("#settingsButton").addEventListener("click", (e) => {
  e.preventDefault();
  settingsAreaForm.classList.toggle("form--hidden");
});

document.querySelector("#profileButton").addEventListener("click", (e) => {
  e.preventDefault();
  userProfileForm.classList.toggle("form--hidden");
  let username = document.getElementById("username").textContent;
  document.getElementById("userHighScore").innerHTML = findHighScore(username);
});

document.querySelectorAll(".form__input").forEach((inputElement) => {
  inputElement.addEventListener("blur", (e) => {
    if (e.target.id === "signupUsername" && e.target.value.length < 10) {
      setInputError(inputElement, "Username must have at least 10 characters");
    }
    else if (e.target.id === "signupUsername" && findUser(e.target.value) === true) {
      setInputError(inputElement, "That username is taken");
    }
  });
  inputElement.addEventListener("input", (e) => {
    clearInputError(inputElement);
  });
});

document.querySelectorAll(".form__input").forEach((inputElement) => {
  inputElement.addEventListener("blur", (e) => {
    if (e.target.id === "signupEmail" && findUser(e.target.value) === true) {
      setInputError(inputElement,"This email is already associated with another account");
    }
  });
  inputElement.addEventListener("input", (e) => {
    clearInputError(inputElement);
  });
});

document.querySelectorAll(".form__input").forEach((inputElement) => {
  inputElement.addEventListener("blur", (e) => {
    if (
        e.target.id === "signupPassConfirm" &&
        document.getElementById("signupPassword").value !== e.target.value) {
      setInputError(inputElement, "Passwords do not match");
    }
    if (e.target.id === "signupPassword") {
      let message = validatePassword();

      if (message != null) {
        setInputError(inputElement, message);
      }
    }
  });
  inputElement.addEventListener("input", (e) => {
    clearInputError(inputElement);
  });
});